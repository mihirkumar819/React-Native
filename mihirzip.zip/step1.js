
import { StyleSheet, Text, View,Image ,StatusBar} from 'react-native';

export default function App() {
  return (
      <View style={[styles.container,{
        flexGrow:1,
        backgroundColor:'creamson'
        
      }]}>
      <StatusBar  
     backgroundColor = "red"  
     barStyle = "dark-content"   
   />  
      <Text>Welcome To Master Page</Text>
      <button> Details </button>
       <Image source={require("./batman.jpg")}/>

       <Text> Title:Batman </Text>
       <Text> First Name:Bruce </Text>
        <Text> First Name:Wayne </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
   // justifyContent: 'center',
  },
});
